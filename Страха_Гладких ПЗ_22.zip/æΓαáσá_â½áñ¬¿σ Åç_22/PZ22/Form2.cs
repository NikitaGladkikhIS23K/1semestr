﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PZ22_KIRILLOV
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 frm1 = this.Owner as Form1; textBox1.Text = frm1.textBox5.Text;
            textBox2.Text = frm1.textBox6.Text;
            textBox3.Text = frm1.textBox7.Text;
            textBox4.Text = frm1.date.Text;
            textBox5.Text = frm1.comboBox1.Text;
            textBox7.Text = frm1.textBox1.Text;
            //pictureBox1 = (Bitmap.FromFile(frm1.openFileDialog_Photo.FileName));

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string selectedFile = openFileDialog1.FileName;
                Image selectedImage = Image.FromFile(selectedFile);
                pictureBox1.Image = selectedImage;
            }
        }
    }
}
