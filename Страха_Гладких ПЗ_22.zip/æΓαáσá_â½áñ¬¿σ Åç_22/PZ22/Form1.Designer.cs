﻿namespace PZ22_KIRILLOV
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            textBox9 = new TextBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            textBox12 = new TextBox();
            textBox13 = new TextBox();
            groupBox1 = new GroupBox();
            comboBox1 = new ComboBox();
            date = new DateTimePicker();
            groupBox2 = new GroupBox();
            textBox1 = new TextBox();
            button1 = new Button();
            checkBox1 = new CheckBox();
            button2 = new Button();
            openFileDialog_Photo = new OpenFileDialog();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.Menu;
            textBox2.BorderStyle = BorderStyle.None;
            textBox2.Font = new Font("Segoe UI", 11F);
            textBox2.Location = new Point(6, 38);
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new Size(88, 20);
            textBox2.TabIndex = 1;
            textBox2.Text = "Фамилия";
            // 
            // textBox3
            // 
            textBox3.BackColor = SystemColors.Menu;
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Font = new Font("Segoe UI", 11F);
            textBox3.Location = new Point(7, 72);
            textBox3.Name = "textBox3";
            textBox3.ReadOnly = true;
            textBox3.Size = new Size(50, 20);
            textBox3.TabIndex = 2;
            textBox3.Text = "Имя";
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // textBox4
            // 
            textBox4.BackColor = SystemColors.Menu;
            textBox4.BorderStyle = BorderStyle.None;
            textBox4.Font = new Font("Segoe UI", 11F);
            textBox4.Location = new Point(6, 114);
            textBox4.Name = "textBox4";
            textBox4.ReadOnly = true;
            textBox4.Size = new Size(88, 20);
            textBox4.TabIndex = 3;
            textBox4.Text = "Отчество";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(101, 39);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(157, 23);
            textBox5.TabIndex = 4;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(63, 73);
            textBox6.Multiline = true;
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(195, 23);
            textBox6.TabIndex = 5;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(101, 111);
            textBox7.Multiline = true;
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(157, 23);
            textBox7.TabIndex = 6;
            // 
            // textBox9
            // 
            textBox9.BackColor = SystemColors.Menu;
            textBox9.BorderStyle = BorderStyle.None;
            textBox9.Font = new Font("Segoe UI", 11F);
            textBox9.Location = new Point(368, 42);
            textBox9.Name = "textBox9";
            textBox9.ReadOnly = true;
            textBox9.Size = new Size(121, 20);
            textBox9.TabIndex = 8;
            textBox9.Text = "Дата рождения";
            // 
            // textBox10
            // 
            textBox10.BackColor = SystemColors.Menu;
            textBox10.BorderStyle = BorderStyle.None;
            textBox10.Font = new Font("Segoe UI", 11F);
            textBox10.Location = new Point(368, 76);
            textBox10.Name = "textBox10";
            textBox10.ReadOnly = true;
            textBox10.Size = new Size(49, 20);
            textBox10.TabIndex = 9;
            textBox10.Text = "Пол";
            // 
            // textBox11
            // 
            textBox11.BackColor = SystemColors.Menu;
            textBox11.BorderStyle = BorderStyle.None;
            textBox11.Font = new Font("Segoe UI", 11F);
            textBox11.Location = new Point(6, 31);
            textBox11.Name = "textBox11";
            textBox11.ReadOnly = true;
            textBox11.Size = new Size(121, 20);
            textBox11.TabIndex = 10;
            textBox11.Text = "Фотография";
            // 
            // textBox12
            // 
            textBox12.BackColor = SystemColors.Menu;
            textBox12.BorderStyle = BorderStyle.None;
            textBox12.Font = new Font("Segoe UI", 11F);
            textBox12.Location = new Point(6, 74);
            textBox12.Name = "textBox12";
            textBox12.ReadOnly = true;
            textBox12.Size = new Size(167, 20);
            textBox12.TabIndex = 11;
            textBox12.Text = "Совершеннолетний(яя)";
            // 
            // textBox13
            // 
            textBox13.BackColor = SystemColors.Menu;
            textBox13.BorderStyle = BorderStyle.None;
            textBox13.Font = new Font("Segoe UI", 11F);
            textBox13.Location = new Point(368, 31);
            textBox13.Name = "textBox13";
            textBox13.ReadOnly = true;
            textBox13.Size = new Size(121, 20);
            textBox13.TabIndex = 12;
            textBox13.Text = "Примечание";
            textBox13.TextChanged += textBox13_TextChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(comboBox1);
            groupBox1.Controls.Add(date);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(textBox4);
            groupBox1.Controls.Add(textBox5);
            groupBox1.Controls.Add(textBox10);
            groupBox1.Controls.Add(textBox6);
            groupBox1.Controls.Add(textBox9);
            groupBox1.Controls.Add(textBox7);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(822, 199);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            groupBox1.Text = "Личные данные";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Женский", "Мужской" });
            comboBox1.Location = new Point(423, 73);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(160, 23);
            comboBox1.TabIndex = 11;
            // 
            // date
            // 
            date.CalendarFont = new Font("Segoe UI", 11F);
            date.Location = new Point(495, 39);
            date.Name = "date";
            date.Size = new Size(278, 23);
            date.TabIndex = 10;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(textBox1);
            groupBox2.Controls.Add(button1);
            groupBox2.Controls.Add(checkBox1);
            groupBox2.Controls.Add(textBox11);
            groupBox2.Controls.Add(textBox12);
            groupBox2.Controls.Add(textBox13);
            groupBox2.Location = new Point(12, 217);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(823, 163);
            groupBox2.TabIndex = 14;
            groupBox2.TabStop = false;
            groupBox2.Text = "Дополнительная информация";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(479, 29);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(274, 106);
            textBox1.TabIndex = 15;
            // 
            // button1
            // 
            button1.Location = new Point(101, 29);
            button1.Name = "button1";
            button1.Size = new Size(91, 27);
            button1.TabIndex = 14;
            button1.Text = "Добавить";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(190, 77);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(40, 19);
            checkBox1.TabIndex = 13;
            checkBox1.Text = "Да";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(721, 409);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 15;
            button2.Text = "Готово";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_1;
            // 
            // openFileDialog_Photo
            // 
            openFileDialog_Photo.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(847, 453);
            Controls.Add(button2);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Создание анкеты";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox9;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox12;
        private TextBox textBox13;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        public Button button1;
        private Button button2;
        private void button2_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2(); frm2.Show(this);
        }

        public TextBox textBox5;
        public TextBox textBox6;
        public TextBox textBox7;
        public DateTimePicker date;
        public CheckBox checkBox1;
        public ComboBox comboBox1;
        public TextBox textBox1;
        public OpenFileDialog openFileDialog_Photo;
    }
}
