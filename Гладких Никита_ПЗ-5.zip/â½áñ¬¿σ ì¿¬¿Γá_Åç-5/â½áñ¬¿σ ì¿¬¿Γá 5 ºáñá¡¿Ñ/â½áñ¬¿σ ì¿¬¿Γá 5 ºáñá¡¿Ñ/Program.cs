﻿using System;
namespace F5
{
    class Program
    {
        static void Main(string[] args)
        {
            double x = 2;
            double y = 5;
            double frX = -x;
            double frY = -y;
            double frXY = -x * -y;
            double otvet = frX - frY / (1 + frXY);
            Console.WriteLine($"Ответ {otvet}");
            Console.ReadKey();
        }
    }
}