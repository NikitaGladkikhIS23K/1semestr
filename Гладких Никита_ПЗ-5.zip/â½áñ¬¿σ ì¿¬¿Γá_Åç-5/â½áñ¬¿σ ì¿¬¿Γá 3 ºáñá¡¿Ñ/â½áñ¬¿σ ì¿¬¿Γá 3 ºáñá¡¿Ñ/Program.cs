﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double x = 9;
        double firstValue, secondValue, otvet;
        firstValue = Math.Pow(x, 2);
        secondValue = Math.Pow(3, 3) * Math.Sqrt(x);
        otvet = 2 * firstValue - secondValue;
        Console.WriteLine("Ответ = " + otvet);
        Console.ReadKey();
    }
}