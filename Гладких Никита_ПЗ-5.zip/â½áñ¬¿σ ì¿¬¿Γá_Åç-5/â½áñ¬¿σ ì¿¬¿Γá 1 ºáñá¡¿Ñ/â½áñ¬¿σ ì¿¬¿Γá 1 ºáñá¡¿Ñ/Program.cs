﻿using System;
class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите число ");
        int cb1 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Введите число ");
        int cb2 = Convert.ToInt32(Console.ReadLine());
        int otvet = Math.Max(cb1, cb2);
        Console.WriteLine("Наибольшее число " + otvet);
    }
}