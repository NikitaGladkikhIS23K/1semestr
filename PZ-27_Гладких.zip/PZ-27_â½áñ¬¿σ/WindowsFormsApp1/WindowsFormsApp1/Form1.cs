﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private string currentFilePath = string.Empty;
        public Form1()
        {
            InitializeComponent();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }
        private void MenuFileOpen()
        {
            if (openFileDialog1.ShowDialog() ==System.Windows.Forms.DialogResult.OK && openFileDialog1.FileName.Length > 0)
            {
                try
                {
                    richTextBox1.LoadFile(openFileDialog1.FileName,
                    RichTextBoxStreamType.RichText);
                }
                catch (System.ArgumentException ex)
                {
                    richTextBox1.LoadFile(openFileDialog1.FileName,
                    RichTextBoxStreamType.PlainText);
                }
                this.Text = "Файл [" + openFileDialog1.FileName + "]";
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MenuFileOpen();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MenuFileSaveAs();
        }

        private void MenuFileSaveAs()
        {
            if (saveFileDialog1.ShowDialog() ==
            System.Windows.Forms.DialogResult.OK &&
            saveFileDialog1.FileName.Length > 0)
            {
                richTextBox1.SaveFile(saveFileDialog1.FileName);
                this.Text = "Файл [" + saveFileDialog1.FileName + "]";
            }
        }
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MenuFileSaveAs();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("Текст документа", new Font("Arial", 20), Brushes.Black, 100, 100);
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog(); 
            if (printDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print(); 
            }
        }

        private void pageSetupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pageSetupDialog1.Document = printDocument1;
            if (pageSetupDialog1.ShowDialog() == DialogResult.OK)
            {
               
            }
        }
    }


}

