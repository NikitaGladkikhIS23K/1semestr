﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

[Serializable]
public class Person
{
    public string Name { get; set; }
    public int[] Marks { get; set; }

    public Person() { }

    public Person(string name, int[] marks)
    {
        Name = name;
        Marks = marks;
    }
}

public class Program
{
    static void Main(string[] args)
    {
        List<Person> people = DeserializePeople("people.xml");

        while (true)
        {
            Console.WriteLine("Команды:");
            Console.WriteLine("0 - Выход;");
            Console.WriteLine("1 - Показать самого лучшего ученика;");
            Console.WriteLine("2 - Показать самого худшего ученика;");
            Console.WriteLine("3 - Показать весь список;");
            Console.WriteLine("4 - Показать учеников со средним баллом больше ...");

            Console.WriteLine("Введите команду:");
            string command = Console.ReadLine();

            switch (command)
            {
                case "0":
                    Console.WriteLine("Выход");
                    return;
                case "1":
                    ShowBestStudent(people);
                    break;
                case "2":
                    ShowWorstStudent(people);
                    break;
                case "3":
                    ShowAllStudents(people);
                    break;
                case "4":
                    ShowStudentsWithAverageGreaterThan(people);
                    break;
                default:
                    Console.WriteLine("Неверная команда");
                    break;
            }
        }
    }

    private static void ShowBestStudent(List<Person> people)
    {
        if (people.Count == 0)
        {
            Console.WriteLine("Список пуст.");
            return;
        }

        Person bestStudent = people.OrderByDescending(p => p.Marks.Average()).First();
        Console.WriteLine($"Лучший ученик {bestStudent.Name}");
        Console.WriteLine($"Оценки: {string.Join(" ", bestStudent.Marks)}");
    }

    private static void ShowWorstStudent(List<Person> people)
    {
        if (people.Count == 0)
        {
            Console.WriteLine("Список пуст.");
            return;
        }

        Person worstStudent = people.OrderBy(p => p.Marks.Average()).First();
        Console.WriteLine($"Худший ученик {worstStudent.Name}");
        Console.WriteLine($"Оценки: {string.Join(" ", worstStudent.Marks)}");
    }

    private static void ShowAllStudents(List<Person> people)
    {
        if (people.Count == 0)
        {
            Console.WriteLine("Список пуст.");
            return;
        }

        Console.WriteLine("Список:");
        foreach (Person person in people)
        {
            Console.WriteLine($"Имя: {person.Name}, Оценки: {string.Join(" ", person.Marks)}");
        }
    }

    private static void ShowStudentsWithAverageGreaterThan(List<Person> people)
    {
        if (people.Count == 0)
        {
            Console.WriteLine("Список пуст.");
            return;
        }

        Console.WriteLine("Введите средний балл:");
        if (!int.TryParse(Console.ReadLine(), out int averageThreshold))
        {
            Console.WriteLine("Неверный формат ввода.");
            return;
        }

        Console.WriteLine($"Средний балл больше {averageThreshold}");

        var filteredPeople = people.Where(p => p.Marks.Average() > averageThreshold);
        foreach (Person person in filteredPeople)
        {
            Console.WriteLine($"Имя: {person.Name}, Оценки: {string.Join(" ", person.Marks)}");
        }
    }

    private static List<Person> DeserializePeople(string fileName)
    {
        List<Person> people;
        try
        {
            using (FileStream fs = new FileStream(fileName, FileMode.Open))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<Person>));
                people = (List<Person>)serializer.Deserialize(fs);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка десериализации: {ex.Message}");
            people = new List<Person>();
        }

        return people;
    }
}