﻿using System;

class Program
{
    static void Main()
    {
        int[] arr = { 10, 25, 30, 35, 40, 45, 50, 55, 60 };
        foreach (int num in arr)
        {
            if (num > 20 && num < 50)
            {
                Console.Write(num + " ");
            }
        }
    }
}