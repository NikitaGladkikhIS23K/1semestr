﻿using System;
using System.IO;
class Program
{
    static void Main(string[] args)
    {
        string filePath = "File.txt";
        int maxLength = 0;
        using (StreamReader reader = new StreamReader(filePath))
        {
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                if (line.Length > maxLength)
                {
                    maxLength = line.Length;
                }
            }
        }
        Console.WriteLine($"Длина самой длинной строки: {maxLength}");
    }
}
