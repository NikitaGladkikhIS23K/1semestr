﻿using System;
namespace program
{
    class Programm
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine(i);
            }
        }
    }
}