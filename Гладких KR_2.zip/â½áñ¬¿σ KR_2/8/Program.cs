﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace program
{
    class Programm
    {
        static void Main()
        {
            int num = Convert.ToInt32(Console.ReadLine());

            int sum = 0;

            for (int i = 1; i <= num; i++)
            {
                if (i % 2 == 1)
                    sum = sum + i;
                Console.WriteLine(sum);

            }
        }
    }
}