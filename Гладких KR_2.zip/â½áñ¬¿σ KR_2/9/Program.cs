﻿using System;

class Program
{
    static void Main()
    {

        int a = Convert.ToInt32(Console.ReadLine());

        int b = Convert.ToInt32(Console.ReadLine());

        if (a < b)
        {
            int sum = 0;
            for (int i = a; i <= b; i++)
            {
                sum += i;
            }
            Console.WriteLine(sum);
        }
        else
        {
            Console.WriteLine("Ошибка: a должно быть меньше b.");
        }
    }
}


