﻿using System;
namespace program
{
    class Programm
    {
        static void Main()
        {
            int num = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i <= num; i++)
            {
                Console.WriteLine(i);
            }
        }
    }
}