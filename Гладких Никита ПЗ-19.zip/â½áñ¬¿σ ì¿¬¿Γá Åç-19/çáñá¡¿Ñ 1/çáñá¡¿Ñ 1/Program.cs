﻿class Program
{
    static void Main()
    {
        // Ввод коэффициентов
        Console.Write("Введите значение a: ");
        double a = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите значение b: ");
        double b = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите значение c: ");
        double c = Convert.ToDouble(Console.ReadLine());

        // Вычисление дискриминанта
        double discriminant = b * b - 4 * a * c;

        // Проверка на наличие действительных корней
        if (discriminant < 0)
        {
            Console.WriteLine("Дискриминант меньше нуля, поэтому действительных корней нет.");
        }
        else
        {
            // Вычисление корней
            double x1 = (-b + Math.Sqrt(discriminant)) / (2 * a);
            double x2 = (-b - Math.Sqrt(discriminant)) / (2 * a);

            // Вывод корней
            Console.WriteLine("Корень 1: " + x1);
            Console.WriteLine("Корень 2: " + x2);
        }
    }
}