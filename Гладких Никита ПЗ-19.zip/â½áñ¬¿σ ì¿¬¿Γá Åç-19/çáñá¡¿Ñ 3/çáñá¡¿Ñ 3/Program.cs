﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите n_min: ");
        int n_min = Convert.ToInt32(Console.ReadLine());
        Console.Write("Введите n_max: ");
        int n_max = Convert.ToInt32(Console.ReadLine());

        // Метод 1: использование цикла for
        int product1 = 1;
        for (int i = n_min; i <= n_max; i++)
        {
            if (i % 2 != 0)
            {
                product1 *= i;
            }
        }
        Console.WriteLine("Метод 1: " + product1);

        // Метод 2: использование цикла while
        int i = n_min;
        int product2 = 1;
        while (i <= n_max)
        {
            if (i % 2 != 0)
            {
                product2 *= i;
            }
            i++;
        }
        Console.WriteLine("Метод 2: " + product2);

        // Метод 3: использование цикла do-while
        i = n_min;
        int product3 = 1;
        do
        {
            if (i % 2 != 0)
            {
                product3 *= i;
            }
            i++;
        } while (i <= n_max);
        Console.WriteLine("Метод 3: " + product3);
    }
}