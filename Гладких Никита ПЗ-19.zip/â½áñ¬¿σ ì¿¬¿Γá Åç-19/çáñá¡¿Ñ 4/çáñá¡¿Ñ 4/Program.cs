﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите n_min: ");
        int n_min = Convert.ToInt32(Console.ReadLine());
        Console.Write("Введите n_max: ");
        int n_max = Convert.ToInt32(Console.ReadLine());
        int product = 1;
        for (int i = n_min; i <= n_max; i++)
        {
            if (i % 4 == 0 && i % 2 == 0)
            {
                product *= i;
            }
        }