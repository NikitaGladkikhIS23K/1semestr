﻿using System;

class Program
{
    static void Main()
    {
        int num_10 = 259, num_2 = 0, num_8 = 0, num_16 = 0;
        int num = num_10, i = 1;
        while (num > 0.0f)
        {
            num_2 = num % 2 * i + num_2;
            num /= 2;
            i *= 10;
        }
        num = num_10;
        i = 1;
        while (num > 0.0f)
        {
            num_8 = num % 2 * i + num_8;
            num /= 8;
            i *= 10;
        }
        num = num_10;
        i = 1;
        while (num > 0.0f)
        {
            num_16 = num % 16 * i + num_8;
            num /= 16;
            i *= 10;
        }
        Console.WriteLine("10: " + num_10 + ", 2: " + num_2 + ", 8: " + num_8 + ", 16: " + num_16);
    }
}
