﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        int[] a = Enumerable.Range(1, 100).ToArray();
        List<int> result = new List<int>();

        foreach (int value in a)
        {
            int y1 = value * (value * value + 12) - 5;
            int y2 = value * (value * value + 1);
            int gcd = Gcd(y1, y2);
            if (gcd > 1)
            {
                result.Add(value);
            }
        }
        Console.WriteLine("Значения a, при которых НОД(y1(a), y2(a)) > 1: " + string.Join(", ", result));
    }

    static int Gcd(int a, int b)
    {
        if (b == 0)
        {
            return a;
        }
        return Gcd(b, a % b);
    }
}