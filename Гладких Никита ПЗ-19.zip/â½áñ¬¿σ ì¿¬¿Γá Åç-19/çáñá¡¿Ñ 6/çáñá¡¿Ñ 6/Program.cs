﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите N: ");
        int n = Convert.ToInt32(Console.ReadLine());

        double sum1 = 0;
        for (int i = 0; i < n; i++)
        {
            sum1 += 1.0 / (2 * i + 1);
        }
        Console.WriteLine("Сумма через цикл: " + sum1);

        double sum2 = 2 - 1.0 / (2 * n + 2);
        Console.WriteLine("Сумма через формулу: " + sum2);

        if (Math.Abs(sum1 - sum2) < double.Epsilon)
        {
            Console.WriteLine("Результаты совпадают.");
        }
        else
        {
            Console.WriteLine("Результаты не совпадают.");
        }
    }
}