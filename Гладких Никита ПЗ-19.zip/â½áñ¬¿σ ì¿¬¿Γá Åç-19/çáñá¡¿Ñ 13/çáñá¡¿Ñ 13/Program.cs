﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Введите шестнадцатеричное число (A2F):");
        string hexNumber = Console.ReadLine();

        try
        {
            int decimalNumber = Convert.ToInt32(hexNumber, 16);
            Console.WriteLine($"{hexNumber}(16) = {decimalNumber}(10)");
        }
        catch (FormatException)
        {
            Console.WriteLine("Некорректный формат шестнадцатеричного числа.");
        }
        catch (OverflowException)
        {
            Console.WriteLine("Введите положительное целое число, допустимый диапазон слишком велик.");
        }
    }
}
