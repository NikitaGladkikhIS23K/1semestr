﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите значение a: ");
        double a = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите значение b: ");
        double b = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите значение c: ");
        double c = Convert.ToDouble(Console.ReadLine());

        double p = (a + b + c) / 2.0;

        double s = Math.Sqrt(p * (p - a) * (p - b) * (p - c));

        Console.WriteLine("Площа треугольника: " + s);
    }
}