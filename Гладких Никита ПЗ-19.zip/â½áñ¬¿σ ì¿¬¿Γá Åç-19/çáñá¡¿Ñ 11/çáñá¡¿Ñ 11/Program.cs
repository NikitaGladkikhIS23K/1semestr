﻿using System;
using System.Text;

namespace Queue
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue queue = new Queue();
            Console.WriteLine("Пример работы с очередью");
            bool isExit = true;
            string temp;
            while (isExit)
            {
                Console.WriteLine("Операции с очередью:");
                Console.WriteLine("1 - Добавить");
                Console.WriteLine("2 - Удалить");
                Console.WriteLine("3 - Показать");
                Console.WriteLine("4 - Очистить");
                Console.WriteLine("5 - Выход");
                temp = Console.ReadLine();
                switch (temp)
                {
                    case "1":
                        {
                            Console.WriteLine("Введите значение:");
                            queue.Add(Console.ReadLine());
                        }
                        break;
                    case "2":
                        {
                            queue.Delete();
                        }
                        break;
                    case "3":
                        {
                            queue.Show();
                        }
                        break;
                    case "4":
                        {
                            queue.Clear();
                        }
                        break;
                    case "5":
                        {
                            isExit = false;
                        }
                        break;
                }
            }
        }
    }
    class Queue
    {
        private Element First { get; set; }
        private Element Last { get; set; }
        public int Count { get; private set; }

        public Queue()
        {
            First = Last = null;
            Count = 0;
        }

        public bool Add(object obj)
        {
            if (First == null)
            {
                First = new Element(obj, null);
                Last = First;
            }
            Element temp = new Element(obj, null);
            Last.NextObject = temp;
            Last = temp;
            Count++;
            return true;
        }
        public bool Delete()
        {
            if (First == null)
                return false;
            Element temp = First.NextObject;
            First = temp;
            Count--;
            return true;
        }
        public bool Clear()
        {
            First = null;
            Count = 0;
            return true;
        }
        public void Show()
        {
            if (Count == 0)
            {
                Console.WriteLine("Очередь пустая");
                return;
            }
            Console.WriteLine("Кол-во элементов: {0}", Count);
            Element temp = First;
            for (int i = 0; i < Count; i++)
            {
                Console.WriteLine(temp.Value.ToString());
                temp = temp.NextObject;
            }
        }
    }
    class Element
    {
        public object Value { get; set; }
        public Element NextObject { get; set; }

        public Element()
        { }
        public Element(object value, Element nextOblect)
        {
            this.Value = value;
            this.NextObject = NextObject;
        }
    }
}