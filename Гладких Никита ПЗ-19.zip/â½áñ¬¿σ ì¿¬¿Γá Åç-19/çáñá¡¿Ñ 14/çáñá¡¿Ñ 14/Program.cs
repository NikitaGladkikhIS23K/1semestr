﻿using System;

class Program
{
    static void Main()
    {
        double phi = (1 + Math.Sqrt(5)) / 2;
        int n = 2;
        long fn1 = 1;
        long fn = 1;

        while (true)
        {
            long fnCurrent = fn + fn1; 
            double ratio = (double)fnCurrent / fn; 

            if (Math.Abs(ratio - phi) < 1e-10)
            {
                Console.WriteLine($"N: {n + 1}, FN: {fnCurrent}, FN-1: {fn}, |FN / FN-1 - φ| < 10^-10");
                break;
            }

            fn1 = fn;
            fn = fnCurrent;
            n++;
        }
    }
}