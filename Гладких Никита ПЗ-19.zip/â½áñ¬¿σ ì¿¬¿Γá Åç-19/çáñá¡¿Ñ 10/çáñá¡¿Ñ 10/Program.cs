﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите значение n: ");
        int n = Convert.ToInt32(Console.ReadLine());
        Console.Write("Введите значение a: ");
        double a = Convert.ToDouble(Console.ReadLine());

        string result = NewtonBinomExpansion(n, a);
        Console.WriteLine("Разложение бинома Ньютона: " + result);
    }

    static string NewtonBinomExpansion(int n, double a)
    {
        string result = "1";
        for (int i = 1; i <= n; i++)
        {
            result += " + " + Math.Pow(a, i) * Math.Pow(n - i, i);
        }
        return result;
    }
}