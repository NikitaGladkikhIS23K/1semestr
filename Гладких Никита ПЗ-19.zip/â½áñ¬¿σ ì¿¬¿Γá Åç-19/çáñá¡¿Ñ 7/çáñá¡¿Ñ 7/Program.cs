﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите значение x: ");
        double x = Convert.ToDouble(Console.ReadLine());

        double sum1 = 1.0;
        for (int i = 1; i < 100; i++)
        {
            sum1 += Math.Pow(x, 2 * i) * Math.Pow(-1, i) / Math.Pow(2, i);
        }
        Console.WriteLine("Значение через разложение в ряд: " + sum1);

        double sum2 = Math.Cos(x);
        Console.WriteLine("Значение через метод Math.Cos(x): " + sum2);

        if (Math.Abs(sum1 - sum2) < double.Epsilon)
        {
            Console.WriteLine("Результаты совпадают.");
        }
        else
        {
            Console.WriteLine("Результаты не совпадают.");
        }
    }
}