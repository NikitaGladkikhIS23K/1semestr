﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите значение x: ");
        double x = Convert.ToDouble(Console.ReadLine());

        double sum1 = 0.0;
        for (int i = 0; i < 100; i++)
        {
            sum1 += Math.Pow(x, 2 * i + 1) * Math.Pow(-1, i) / Math.Pow(2, 2 * i + 1);
        }
        Console.WriteLine("Значение через разложение в ряд: " + sum1);

        double sum2 = Math.Tan(x);
        Console.WriteLine("Значение через метод Math.Tan(x): " + sum2);

        if (Math.Abs(sum1 - sum2) < double.Epsilon)
        {
            Console.WriteLine("Результаты совпадают.");
        }
        else
        {
            Console.WriteLine("Результаты не совпадают.");
        }
    }
}