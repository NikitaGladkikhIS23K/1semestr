﻿using System;

class Program
{
    static void Main()
    {
        int result = Sum();
        Console.WriteLine(result);
    }

    static int Sum()
    {
        int temp = Convert.ToInt32(Console.ReadLine());

        if (temp == 0)
        {
            return 0;
        }
        else
        {
            return temp + Sum();
        }
    }
}
