﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите число (unsigned long): ");
        string input = Console.ReadLine();

        ulong number;

        if (ulong.TryParse(input, out number))
        {
            string binaryRepresentation = Convert.ToString((long)number, 2);
            Console.WriteLine($"Двоичное представление числа {number} равно: {binaryRepresentation}");

            int zeroCount = CountZeros(binaryRepresentation);

            Console.WriteLine($"Количество нулей в двоичном представлении: {zeroCount}");
        }
        else
        {
            Console.WriteLine("Некорректный ввод. Пожалуйста, введите допустимое число.");
        }
    }

    static int CountZeros(string binary)
    {
        int count = 0;
        foreach (char bit in binary)
        {
            if (bit == '0')
            {
                count++;
            }
        }
        return count;
    }
}
