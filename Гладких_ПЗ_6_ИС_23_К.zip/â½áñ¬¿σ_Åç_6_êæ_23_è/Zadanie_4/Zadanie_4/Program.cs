﻿using System;

using System.Text.RegularExpressions;
class Program
{
    static void Main()
    {
        Console.Write("Введите номер телефона: ");
        string input = Console.ReadLine();

        if (Regex.IsMatch(input, @"^(\+7\s?7\d{3})\s?\d{3}-\d{2}-\d{3}$"))
        {
            long number = long.Parse(input.Replace("(", "").Replace(")", "").Replace("+", ""));
            string result = string.Format("{0:+# (###) ###-##-##}", number);
            Console.WriteLine(result);
        }
        else
        {
            Console.WriteLine("Некорректный формат номера телефона");
        }
    }
}