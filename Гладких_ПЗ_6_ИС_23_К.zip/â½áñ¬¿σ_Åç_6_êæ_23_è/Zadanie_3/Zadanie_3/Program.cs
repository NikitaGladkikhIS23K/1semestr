﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Курский государственный политехнический колледж");
        Console.WriteLine("Контактная информация");
        Console.WriteLine("Контактные телефоны: +7 (4712) 37-02-19");
        Console.WriteLine("Контактный факс: +7 (4712) 37-02-19");
    }
}