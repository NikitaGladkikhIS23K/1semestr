﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.Title = "Средства форматирования строк в C#";

        string theString = "Добрый день!";
        int theInt = 17;
        float theFloat = 12.88F;
        double theDouble = 123.456789;
        BasicIO theClass = new BasicIO();

        Console.WriteLine("Без параметров форматирования:");
        Console.WriteLine("string: {0}", theString);
        Console.WriteLine("int: {0}", theInt);
        Console.WriteLine("float: {0}", theFloat);
        Console.WriteLine("double: {0}", theDouble);
        Console.WriteLine("object: {0}", theClass);

        Console.Write("\n\n");

        object[] array = { "Писеr!", 20.9, 12, "77", Math.PI };
        Console.WriteLine("Элемент массива:\n{0}; {1}; {2}; {3}; {4}", array);
        Console.Write("\n\n");

        Console.WriteLine("С параметрами форматирования: ");
        Console.WriteLine("C format: {0:C}", 99989.987);
        Console.WriteLine("D9 format: {0:D9}", 99999);
        Console.WriteLine("E format: {0:E}", .31415926538 * 10);
        Console.WriteLine("F format: {0:F3}", 55555.6666);
        Console.WriteLine("N format: {0:N}", 99999);
        Console.WriteLine("X format: {0:X}", 99999);
        Console.WriteLine("x format: {0:x}", 99999);

        Console.Write("\n\n");

        string str;
        str = string.Format("C format: {0:C}", 99989.987);
        Console.WriteLine("Предварительное форматирование в символьную строку:");

        Console.WriteLine(str);

        str = "MO: {0}, Возраст: {1}";
        str = string.Format(str, "Васильева В.М.", 19);
        Console.WriteLine("\n\nПредварительное форматирование в символьную строку:");
        Console.WriteLine(str);
        Console.ReadKey();
    }
}