﻿internal class BasicIO
{
    public BasicIO()
    {
    }
}