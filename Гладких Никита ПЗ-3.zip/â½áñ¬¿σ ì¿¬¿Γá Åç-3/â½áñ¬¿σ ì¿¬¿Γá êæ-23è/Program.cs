﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Programm_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            Console.WriteLine("Введите Ваше имя: ");
            name = Console.ReadLine();
            Console.WriteLine("Присутствует Вас, " + name + " ! ");
        }
    }
}
