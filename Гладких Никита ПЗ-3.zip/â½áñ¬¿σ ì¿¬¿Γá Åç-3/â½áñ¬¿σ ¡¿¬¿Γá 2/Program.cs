﻿// 01_01.cs - Первая программа
using System;
using static System.Console;
class HelloUser
{
    static void Main()
    {
        string name;
        Console.WriteLine("Введите ваше имя:");
        name = ReadLine();
        Console.WriteLine("Присутствует Вас, " + name + "!");
        Console.WriteLine("/infl завершение сеанса нажмите Enter. ");
        ReadLine();
    }

}