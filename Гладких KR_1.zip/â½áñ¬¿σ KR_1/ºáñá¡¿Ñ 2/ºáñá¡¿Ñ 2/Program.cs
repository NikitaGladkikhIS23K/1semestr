﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        string[] input = Console.ReadLine().Split(' ');
        int A = int.Parse(input[0]);
        int B = int.Parse(input[1]);

        int positiveCount = 0;

        for (int i = A; i <= B; i++)
        {
            string octal = Convert.ToString(i, 8);

            int newNumber = CalculateNewNumber(octal);

            int distance = i - newNumber;

            if (distance > 0)
            {
                positiveCount++;
            }
        }

        Console.WriteLine(positiveCount);
    }

    private static int CalculateNewNumber(string octal)
    {
        int penultimateDigit = int.Parse(octal[octal.Length - 2].ToString());
        int lastDigit = int.Parse(octal[octal.Length - 1].ToString());

        if (penultimateDigit == 7)
        {
            penultimateDigit = 0;

            if (lastDigit % 2 == 0)
            {
                lastDigit++;
            }
            else
            {
                lastDigit--;
            }
        }
        else
        {
            penultimateDigit++;
        }

        string newOctal = octal.Substring(0, octal.Length - 2) + penultimateDigit.ToString() + lastDigit.ToString();

        return Convert.ToInt32(newOctal, 8);
    }
}
