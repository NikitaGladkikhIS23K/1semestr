﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        string[] input = Console.ReadLine().Split(' ');
        int n = int.Parse(input[0]);

        int count = 0;

        for (int i = 1; i <= n; i++)
        {
            string number = input[i];
            if (IsValidNumber(number))
            {
                count++;
            }
        }

        Console.WriteLine(count);
    }

    static bool IsValidNumber(string number)
    {
        if (number.Length != 6 || !number.EndsWith("00"))
        {
            return false;
        }

        int Decimal = int.Parse(number);
        int binary = Convert.ToInt32(number, 2);

        return Decimal == binary;
    }
}