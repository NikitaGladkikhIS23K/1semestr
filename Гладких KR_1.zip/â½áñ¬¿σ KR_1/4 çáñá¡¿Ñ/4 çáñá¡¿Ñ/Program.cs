﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        string[] input = Console.ReadLine().Split(' ');
        int n = int.Parse(input[0]);

        Dictionary<char, int> wordCount = new Dictionary<char, int>();

        for (int i = 1; i <= n; i++)
        {
            string word = input[i];
            if (wordCount.ContainsKey(word[0]))
            {
                wordCount[word[0]]++;
            }
            else
            {
                wordCount[word[0]] = 1;
            }
        }

        int maxCount = 0;
        int result = 0;

        foreach (var item in wordCount)
        {
            if (item.Value > maxCount)
            {
                maxCount = item.Value;
                result = item.Key - 'a' + 1;
            }
        }

        Console.WriteLine(result);
    }
}