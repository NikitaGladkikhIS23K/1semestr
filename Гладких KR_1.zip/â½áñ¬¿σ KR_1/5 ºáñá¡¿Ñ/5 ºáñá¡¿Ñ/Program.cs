﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        double t = double.Parse(Console.ReadLine());
        int minDay = -1;
        int countAbove = 0;
        int minDays = 0;

        for (int i = 0; i < n; i++)
        {
            double ti = double.Parse(Console.ReadLine());

            if (ti < t && minDay == -1)
            {
                minDay = i + 1;
            }

            if (ti > t)
            {
                countAbove++;
            }
        }

        if (minDay == -1)
        {
            Console.WriteLine("Нет дней с минимальной температурой.");
        }
        else
        {
            Console.WriteLine($"Наименьшая температура отмечена на {minDay}-й день.");
        }

        Console.WriteLine($"{countAbove} дней отмечалась температура выше порогового значения.");
    }
}
