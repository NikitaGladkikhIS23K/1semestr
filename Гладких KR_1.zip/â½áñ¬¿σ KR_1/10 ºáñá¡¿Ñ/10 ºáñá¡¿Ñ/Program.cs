﻿using System;
using System.Linq;

public class Program
{
    public static void Main(string[] args)
    {
        string[] input = Console.ReadLine().Split();
        int n = int.Parse(input[0]);

        int[] packets = new int[n];
        for (int i = 0; i < n; i++)
        {
            packets[i] = int.Parse(input[i + 1]);
        }

        int maxUncorrupted = 0;


        for (int i = 0; i < n; i++)
        {

            int countOnes = CountOnes(packets[i]);


            if (countOnes % 2 != 0)
            {
                packets[i] ^= 1;
            }


            if (packets[i] > maxUncorrupted)
            {
                maxUncorrupted = packets[i];
            }
        }

        Console.WriteLine(maxUncorrupted);
    }


    static int CountOnes(int number)
    {
        int count = 0;
        while (number > 0)
        {
            if (number % 2 == 1)
            {
                count++;
            }
            number /= 2;
        }
        return count;
    }
}