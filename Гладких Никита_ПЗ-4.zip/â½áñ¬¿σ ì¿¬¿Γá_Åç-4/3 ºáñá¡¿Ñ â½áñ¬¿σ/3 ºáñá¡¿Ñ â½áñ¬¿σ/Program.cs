﻿//Приглашение пользователю ввести первое число
Console.Write("Введите первое число и нажмите клавишу Enter: ");

//Получение первой строки
string firstString = Console.ReadLine();

//Преобразование первой строки в число
int firstArg = Convert.ToInt32(firstString);

//Приглашение пользователю ввести второе число
Console.Write("Введите второе число и нажмите клавишу Enter: ");

//Получение второй строки
string secondString = Console.ReadLine();

//Преобразование второй строки в число
int secondArg = Convert.ToInt32(secondString);

//Сложение двух переменных
int result = firstArg + secondArg;

//Вывод результата
Console.WriteLine("Результат сложения введенных чисел: " + result.ToString());

/*
* Обратите внимание на запись result.ToString(),
* тут мы преобразовали число в строку, вызвав
* метод ToString на переменной result!
* Этой операцией мы будем пользоваться часто. 
*/
