﻿class MyClass
{
    public MyClass()
    {
        // код
    }
    public void DoSomething()
    {
        // код
    }
}
sealed class MysealedClass : MyClass
{
    public MysealedClass()
    {
        // код
    }
    public void DoSomethingElse()
    {
        // код
    }
}