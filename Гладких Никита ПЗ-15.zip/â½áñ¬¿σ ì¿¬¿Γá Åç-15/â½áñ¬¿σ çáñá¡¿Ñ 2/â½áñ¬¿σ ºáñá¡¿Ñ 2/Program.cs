﻿class Person
{
    public void Go()
    {
        Console.WriteLine("Человек идет");
    }
}